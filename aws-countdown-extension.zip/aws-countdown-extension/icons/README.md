# Extension Icons

This directory contains the extension icons in the required sizes:

- icon16.png (16x16 pixels) - Used in the extension toolbar
- icon48.png (48x48 pixels) - Used in the extension management page  
- icon128.png (128x128 pixels) - Used in the Chrome Web Store and installation
- icon.svg (source file) - SVG source for generating PNG icons

## Icon Design
The icons feature an AWS-themed countdown timer design:
- AWS Orange (#FF9900) background circle
- AWS Dark Blue (#232F3E) clock face
- Clock hands positioned at 10:00 (representing 10-minute timer)
- Clean, professional appearance suitable for Chrome toolbar

## Converting SVG to PNG
To generate the required PNG files from the SVG source:

### Using ImageMagick (Command Line)
```bash
convert icon.svg -resize 16x16 icon16.png
convert icon.svg -resize 48x48 icon48.png  
convert icon.svg -resize 128x128 icon128.png
```

### Using Online Converters
1. Upload `icon.svg` to any SVG-to-PNG converter
2. Generate three sizes: 16x16, 48x48, 128x128
3. Save as `icon16.png`, `icon48.png`, `icon128.png`

### Using Design Software
- Open `icon.svg` in Inkscape, Adobe Illustrator, or similar
- Export as PNG at the required dimensions
- Ensure transparent background is maintained

## Installation Note
The PNG files are required for the extension to load properly in Chrome. The extension will not function without these icon files.